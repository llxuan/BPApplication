#!/bin/sh
make -C '/Users/apple/Desktop/digit ios/build-digits_ios-iphoneos_clang_Qt_5_6_2_for_iOS-Debug/' -f digits_ios.xcodeproj/qt_makeqmake.mak
