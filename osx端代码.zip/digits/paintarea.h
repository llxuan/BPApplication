#ifndef PAINTAREA_H
#define PAINTAREA_H
#include <QMainWindow>
#include <QWidget>
#include <QtGui>
#include <QMouseEvent>
#include <QPaintEvent>
#include <QResizeEvent>
#include <QColor>
#include <QPixmap>
#include <QPoint>
#include <QPainter>
#include <QPalette>



#endif // PAINTAREA_H
